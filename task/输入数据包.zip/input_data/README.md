# 内容安全回放材料

内容安全平台运行组整理了这批材料，用于把现有按日串行DAG迁到Dataset触发的分片回放流程。

- orchestration_contract.yaml记录DAG名称、Dataset、并发边界和资源池。
- replay_windows.csv记录需要回放的业务窗口和事件Dataset。
- policy_shards.jsonl记录策略分片、队列、事件基数和资源池。
- current_dag/content_moderation_replay.py是线上当前使用的串行DAG源文件。
- release_request.json记录本次发布窗口、影响范围、观察项和退回条件。

平台工程师负责整理候选DAG与发布材料。内容安全值班人按发布请求安排切换，并在调度器中完成现场检查。
