from datetime import datetime

from airflow.decorators import dag, task


@dag(
    dag_id="content_moderation_replay",
    schedule="@daily",
    start_date=datetime(2025, 1, 1),
    catchup=True,
)
def content_moderation_replay():
    @task
    def process_all():
        return {"mode": "serial", "source": "daily_schedule"}

    process_all()


content_moderation_replay()
