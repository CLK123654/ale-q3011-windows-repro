# 内容安全回放发布材料

dags目录保存候选AirflowDAG。reports目录保存回放计划、资源池分配、Dataset血缘和DAG结构。release-summary.json供内容安全值班人安排维护窗切换、观察和退回。
